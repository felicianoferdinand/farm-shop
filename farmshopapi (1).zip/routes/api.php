<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\ApiController;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\PagesController;
use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\ProductController;
use App\Http\Controllers\Admin\OrderController;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

Route::middleware('api')->group(function () {
    Route::get('/', [ApiController::class, 'index']);
    Route::get('/add-cart/{productid}/{userid}', [ApiController::class, 'cart']);
    Route::get('/cart/{id}', [ApiController::class, 'shopping_cart']);
    Route::get('/cart/remove/{id}', [ApiController::class, 'remove_cart']);
    Route::get('/check-out/{id}', [ApiController::class, 'check_out']);
    Route::post('/check-out/{userid}', [ApiController::class, 'check_out_store']);

    Route::post('/login', [AuthController::class, 'login']);
    Route::post('/register', [AuthController::class, 'register']);

    Route::get('/get-order/{userid}', [PagesController::class, 'get_orders']);
    Route::get('/get-product/{id}', [PagesController::class, 'get_product']);
    

    Route::get('/admin/category', [CategoryController::class, 'index']);
    Route::get('/admin/create/category', [CategoryController::class, 'store']);
    Route::post('/admin/update/category/{id}', [CategoryController::class, 'update']);
    Route::post('/admin/delete/category/{id}', [CategoryController::class, 'destroy']);
    Route::get('/admin/category/{id}', [CategoryController::class, 'getbyid']);

    Route::get('/admin/product', [ProductController::class, 'index']);
    Route::get('/admin/create/product', [ProductController::class, 'store']);
    Route::post('/admin/update/product/{id}', [ProductController::class, 'update']);
    Route::post('/admin/delete/product/{id}', [ProductController::class, 'destroy']);
    Route::get('/admin/product/{id}', [ProductController::class, 'getbyid']);

    Route::get('/admin/order', [OrderController::class, 'index']);
    Route::post('/admin/update/order/{id}', [OrderController::class, 'update']);
    Route::get('/admin/order/{id}', [OrderController::class, 'getbyid']);

    Route::get('/{nama}', [ApiController::class, 'index']);
});