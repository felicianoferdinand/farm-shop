<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{

     /**
 * @OA\Post(
 *     path="/api/login",
 *     summary="Login",
 *     @OA\RequestBody(
 *         required=true,
 *         description="Login",
 *         @OA\JsonContent(
 *             required={"email", "password"},
 *             @OA\Property(property="email", type="string", example="email@email.com"),
 *             @OA\Property(property="password", type="string", example="password"),
 *         ),
 *     ),
 *     @OA\Response(
 *         response=200,
 *         description="Successful operation",
 *         @OA\JsonContent(
 *             @OA\Property(property="status", type="boolean", example=true),
 *             @OA\Property(property="message", type="string", example="Login Success"),
 *         ),
 *     ),
 * )
 */
    public function login(Request $request)
    {
        $credentials = [
            'email' => $request->email,
            'password' => $request->password,
        ];

        if (Auth::attempt($credentials)) {
            $user = Auth::user(); 
            return response()->json([
                'status' => true,
                'message' => 'Berhasil login',
                'user_id' => $user->id,
                'level' => $user->level
            ]);
        }
        
        return response()->json([
            'status' => false,
            'message' => 'Data login salah',
            'user_id' => null,
            'level' => null,
        ]);
    }

     /**
 * @OA\Post(
 *     path="/api/register",
 *     summary="register",
 *     @OA\RequestBody(
 *         required=true,
 *         description="register",
 *         @OA\JsonContent(
 *             required={"name", "email", "password"},
 *             @OA\Property(property="name", type="string", example="name"),
 *             @OA\Property(property="email", type="string", example="email@email.com"),
 *             @OA\Property(property="password", type="string", example="password"),
 *         ),
 *     ),
 *     @OA\Response(
 *         response=200,
 *         description="Successful operation",
 *         @OA\JsonContent(
 *             @OA\Property(property="status", type="boolean", example=true),
 *             @OA\Property(property="message", type="string", example="Register Success"),
 *         ),
 *     ),
 * )
 */
    public function register(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required|unique:users',
            'password' => 'required',
        ]);


        $user = User::create([
            'level' => 'member',
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
        ]);

        if ($user) {
            return response()->json([
                'status' => true,
                'message' => 'Registrasi berhasil',
                'user' => $user,
            ]);
        }
        
        return response()->json([
            'status' => false,
            'message' => 'Registrasi gagal',
            'user' => null,
        ]);
    }
}
