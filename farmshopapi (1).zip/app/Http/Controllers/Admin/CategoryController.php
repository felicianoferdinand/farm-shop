<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\category;

class CategoryController extends Controller
{
     /**
     * @OA\Get(
     *     path="/admin/category",
     *     summary="Get category",
     *     @OA\Response(
     *         response=200,
     *         description="OK",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="boolean", example=true),
     *             @OA\Property(property="data", type="string"),
     *         )
     *     )
     * )
     */
    public function index()
    {
        $get = category::all();

        if($get) {
            return response()->json([
                'status' => true,
                'data' => $get
            ]);
        } else {
            return response()->json([
                'status' => false,
                'data' => null
            ]);
        }
    }

     /**
     * @OA\Get(
     *     path="/admin/category/{id}",
     *     summary="Get category id",
     *     @OA\Response(
     *         response=200,
     *         description="OK",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="boolean", example=true),
     *             @OA\Property(property="data", type="string"),
     *         )
     *     )
     * )
     */ 
    public function getbyid($id)
    {
        $get = category::find($id);

        if($get) {
            return response()->json([
                'status' => true,
                'data' => $get
            ]);
        } else {
            return response()->json([
                'status' => false,
                'data' => null
            ]);
        }
    }

    /**
 * @OA\Post(
 *    path="/admin/create/category",
 *     summary="create category",
 *     @OA\RequestBody(
 *         required=true,
 *         description="Checkout details",
 *         @OA\JsonContent(
 *             required={"name"},
 *             @OA\Property(property="name", type="string", example="name")
 *         ),
 *     ),
 *     @OA\Response(
 *         response=200,
 *         description="Successful operation",
 *         @OA\JsonContent(
 *             @OA\Property(property="status", type="boolean", example=true),
 *             @OA\Property(property="data", type="string"),
 *         ),
 *     ),
 * )
 */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
        ]);

        $create = category::create([
            'name' => $request->name
        ]);

        if($create) {
            return response()->json([
                'status' => true,
                'data' => $create
            ]);
        } else {
            return response()->json([
                'status' => false,
                'data' => null
            ]);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
 * @OA\Post(
 *    path="/admin/update/category/{id}",
 *     summary="update category",
 *     @OA\RequestBody(
 *         required=true,
 *         description="Checkout details",
 *         @OA\JsonContent(
 *             required={"name"},
 *             @OA\Property(property="name", type="string", example="name")
 *         ),
 *     ),
 *     @OA\Response(
 *         response=200,
 *         description="Successful operation",
 *         @OA\JsonContent(
 *             @OA\Property(property="status", type="boolean", example=true),
 *             @OA\Property(property="data", type="string"),
 *         ),
 *     ),
 * )
 */
    public function update(Request $request, string $id)
    {
        $request->validate([
            'name' => 'required',
        ]);

        $update = category::find($id)->update([
            'name' => $request->name
        ]);

        if($update) {
            return response()->json([
                'status' => true,
                'data' => $update
            ]);
        } else {
            return response()->json([
                'status' => false,
                'data' => null
            ]);
        }
    }

     /**
     * @OA\Get(
     *     path="/admin/delete/category/{id}",
     *     summary="delete category id",
     *     @OA\Response(
     *         response=200,
     *         description="OK",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="boolean", example=true),
     *             @OA\Property(property="data", type="string"),
     *         )
     *     )
     * )
     */ 
    public function destroy(string $id)
    {
        $get = category::find($id);
        $get->delete();

        return response()->json([
            'status' => true,
            'data' => null
        ]);
    }
}
