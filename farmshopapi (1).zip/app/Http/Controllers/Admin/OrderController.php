<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\order;

class OrderController extends Controller
{
     /**
     * @OA\Get(
     *     path="/admin/order",
     *     summary="Get order",
     *     @OA\Response(
     *         response=200,
     *         description="OK",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="boolean", example=true),
     *             @OA\Property(property="data", type="string"),
     *         )
     *     )
     * )
     */
    public function index()
    {
        $get = order::all();

        if($get) {
            return response()->json([
                'status' => true,
                'message' => 'Data berhasil di ambil',
                'data' => $get
            ]);
        } else {
            return response()->json([
                'status' => false,
                'message' => 'System Error',
                'data' => null
            ]);
        }
    }

    /**
     * @OA\Get(
     *     path="/admin/order/{id}",
     *     summary="Get order id",
     *     @OA\Response(
     *         response=200,
     *         description="OK",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="boolean", example=true),
     *             @OA\Property(property="data", type="string"),
     *         )
     *     )
     * )
     */
    public function getbyid($id)
    {
        $get = order::find($id);

        if($get) {
            return response()->json([
                'status' => true,
                'message' => 'Data berhasil di ambil',
                'data' => $get
            ]);
        } else {
            return response()->json([
                'status' => false,
                'message' => 'System Error',
                'data' => null
            ]);
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
      
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

      /**
 * @OA\Post(
 *    path="/admin/update/order/{id}",
 *     summary="update order",
 *     @OA\RequestBody(
 *         required=true,
 *         description="Checkout details",
 *         @OA\JsonContent(
 *             required={"status"},
 *             @OA\Property(property="status", type="string", example="status"),
 *         ),
 *     ),
 *     @OA\Response(
 *         response=200,
 *         description="Successful operation",
 *         @OA\JsonContent(
 *             @OA\Property(property="status", type="boolean", example=true),
 *             @OA\Property(property="data", type="string"),
 *         ),
 *     ),
 * )
 */
    public function update(Request $request, string $id)
    {
        $update = order::find($id);
        $update->update([
            'status' => $request->status,
        ]);

        if($update) {
            return response()->json([
                'status' => true,
                'data' => $update
            ]);
        } else {
            return response()->json([
                'status' => false,
                'data' => null
            ]);
        }
    }
    public function destroy(string $id)
    {

    }
}
