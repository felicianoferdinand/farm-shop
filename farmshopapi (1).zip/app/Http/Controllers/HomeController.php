<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\product;
use App\Models\shopping_cart;
use App\Models\order;
use GuzzleHttp\Client;

class HomeController extends Controller
{
    public function index(){

        $client = new Client();
        $response = $client->request('GET', 'http://127.0.0.1:8080/api/pages/index');
        $data = json_decode($response->getBody(), true);

        return view('pages.index', [
            'countproduct' => $data['countproduct'],
            'product' => $data['product']
        ]);
    }

    public function shopping_cart($id){

        $get_cart = shopping_cart::where('user_id', $id)->get();
        return view('pages.cart', [
            'cart' => $get_cart,
            'totalprice' => $get_cart->sum('harga')
        ]);
    }

    public function check_out($id){

        $get_cart = shopping_cart::where('user_id', $id)->get();
        return view('pages.checkout', [
            'cart' => $get_cart,
            'totalprice' => $get_cart->sum('harga')
        ]);
    }

    public function check_out_store(Request $request){

        $validatedData = $request->validate([
            'full_name' => 'required',
            'address' => 'required',
            'city' => 'required',
            'state' => 'required',
            'postcode' => 'required',
            'phone' => 'required',
            'note' => 'required',
            'bukti_pembayaran' => 'required',
        ]);

        $get_cart = shopping_cart::where('user_id', 1)->get();

        if(!$get_cart || empty($get_cart)) {
            return back()->with('error', 'Pilih product terlebih dahulu');
        }

        $total_harga =  $get_cart->sum('harga');
        
        $cart = [];
        foreach ($get_cart as $datacart) {
            $get_product = product::find($datacart->product_id);

            if($get_product->stock <  $datacart->amount) {
                return back()->with('error', 'Stock tidak cukup');
            }

            $array = [
                'product_id' => $datacart->product_id,
                'amount' => $datacart->amount
            ];
            array_push($cart, $array);
        }

        if(empty($cart)) {
            return back()->with('error', 'Pilih product terlebih dahulu');
        }

        foreach ($get_cart as $datacart) {
            $get_product = product::find($datacart->product_id);
            $stock_now = $get_product->stock - $datacart->amount;
            $get_product->update(['stock' => $stock_now]);
        }

        if ($request->hasFile('bukti_pembayaran')) {
            $fileNameimage = time() . '-image' . '.' . $request->bukti_pembayaran->extension();
            $imagePath = $request->bukti_pembayaran->move('uploads', $fileNameimage)->getPath();
            $image = $imagePath . '/' . $fileNameimage;
        }

        $data = [
            'user_id' => 1,
            'product' => json_encode($get_cart),
            'full_name' => $request->full_name,
            'address'  => $request->address,
            'city'  => $request->city,
            'state'  => $request->state,
            'postcode'  => $request->postcode,
            'phone'  => $request->phone,
            'note'  => $request->note,
            'total_harga'  => $total_harga,
            'bukti_pembayaran'  => $image,
            'status' => 'Waiting',
        ];

        $create = order::create($data);

        foreach ($get_cart as $cart_item) {
            $cart_item->delete();
        }

        if($create) {
            return redirect()->route('index')->with('success', 'Pembelian berhasil silakan tunggu admin untuk tahap selanjutnya');
        } else {
            return redirect()->route('index')->with('error', 'System Error !!');
        }
    }

    public function remove_cart(Request $request, $id){

        $get_cart = shopping_cart::where('id', $id)->delete();
        if($get_cart) {
            return back()->with('success', 'Cart berhasil di remove');
        } else {
            return back()->with('error', 'System Error !!');
        }
    }

    public function cart(Request $request, $productid){
        $get_product = product::find($productid);

        $check_cart = shopping_cart::where(['user_id' => 1, 'product_id' => $get_product->id])->first();

        if($check_cart) {
            $get_amount = $check_cart->amount + 1;

                if($get_product->stock < $get_amount) {
                    return back()->with('error', 'Stock tidak cukup');
                }

            $get_total_harga =  $get_amount * $get_product->harga;

            $add = shopping_cart::where(['user_id' => 1, 'product_id' => $get_product->id])->update([
                'amount' => $get_amount,
                'harga' => $get_total_harga,
            ]);
        } else {
            $get_amount = 1;

            if($get_product->stock < $get_amount) {
                return back()->with('error', 'Stock tidak cukup');
            }

            $get_total_harga =  $get_amount * $get_product->harga;

            $add = shopping_cart::create([
                'user_id' => 1,
                'product_id' =>  $get_product->id,
                'amount' => $get_amount,
                'harga' => $get_total_harga,
            ]);
        }

        if($add) {
            return back()->with('success', 'Berhasil di tambah ke keranjang');
        } else {
            return back()->with('error', 'System Error !!');
        }
    }
}
