<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\product;

class ProductController extends Controller
{
    /**
     * @OA\Get(
     *     path="/admin/product",
     *     summary="Get product",
     *     @OA\Response(
     *         response=200,
     *         description="OK",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="boolean", example=true),
     *             @OA\Property(property="data", type="string"),
     *         )
     *     )
     * )
     */
    public function index()
    {
        try {
            $products = product::all();

            return response()->json([
                'status' => true,
                'message' => 'Data retrieved successfully',
                'data' => $products
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'System Error: ' . $e->getMessage(),
                'data' => null
            ], 500);
        }
    }

    /**
     * @OA\Get(
     *     path="/admin/product/{id}",
     *     summary="Get product id",
     *     @OA\Response(
     *         response=200,
     *         description="OK",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="boolean", example=true),
     *             @OA\Property(property="data", type="string"),
     *         )
     *     )
     * )
     */
    public function getbyid($id)
    {
        $get = product::find($id);

        if($get) {
            return response()->json([
                'status' => true,
                'message' => 'Data berhasil di ambil',
                'data' => $get
            ]);
        } else {
            return response()->json([
                'status' => false,
                'message' => 'System Error',
                'data' => null
            ]);
        }
    }

      /**
 * @OA\Post(
 *    path="/admin/create/product",
 *     summary="create product",
 *     @OA\RequestBody(
 *         required=true,
 *         description="Checkout details",
 *         @OA\JsonContent(
 *             required={"image","category_id","nama","deskripsi","harga","stock"},
 *             @OA\Property(property="image", type="string", example="image"),
 *             @OA\Property(property="category_id", type="number", example="category_id"),
 *             @OA\Property(property="nama", type="string", example="nama"),
 *             @OA\Property(property="deskripsi", type="string", example="deskripsi"),
 *             @OA\Property(property="harga", type="string", example="harga"),
 *             @OA\Property(property="stock", type="number", example="stock")
 *         ),
 *     ),
 *     @OA\Response(
 *         response=200,
 *         description="Successful operation",
 *         @OA\JsonContent(
 *             @OA\Property(property="status", type="boolean", example=true),
 *             @OA\Property(property="data", type="string"),
 *         ),
 *     ),
 * )
 */
    public function store(Request $request)
    {
        $request->validate([
            'image' => 'required',
            'category_id' => 'required',
            'nama' => 'required',
            'deskripsi' => 'required',
            'harga' => 'required',
            'stock' => 'required',
        ]);

        $create = product::create([
            'image' => $request->image,
            'category_id' => $request->category_id,
            'nama' => $request->nama,
            'deskripsi' => $request->deskripsi,
            'harga' => $request->harga,
            'stock' => $request->stock,
        ]);

        if($create) {
            return response()->json([
                'status' => true,
                'data' => $create
            ]);
        } else {
            return response()->json([
                'status' => false,
                'data' => null
            ]);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
 * @OA\Post(
 *    path="/admin/update/product/{id}",
 *     summary="update product",
 *     @OA\RequestBody(
 *         required=true,
 *         description="Checkout details",
 *         @OA\JsonContent(
 *             @OA\Property(property="image", type="string", example="image"),
 *             @OA\Property(property="category_id", type="number", example="category_id"),
 *             @OA\Property(property="nama", type="string", example="nama"),
 *             @OA\Property(property="deskripsi", type="string", example="deskripsi"),
 *             @OA\Property(property="harga", type="string", example="harga"),
 *             @OA\Property(property="stock", type="number", example="stock")
 *         ),
 *     ),
 *     @OA\Response(
 *         response=200,
 *         description="Successful operation",
 *         @OA\JsonContent(
 *             @OA\Property(property="status", type="boolean", example=true),
 *             @OA\Property(property="data", type="string"),
 *         ),
 *     ),
 * )
 */
    public function update(Request $request, string $id)
    {
        $update = product::find($id);
        $update->update([
            'image' => $request->image,
            'category_id' => $request->category_id,
            'nama' => $request->nama,
            'deskripsi' => $request->deskripsi,
            'harga' => $request->harga,
            'stock' => $request->stock,
        ]);

        if($update) {
            return response()->json([
                'status' => true,
                'data' => $update
            ]);
        } else {
            return response()->json([
                'status' => false,
                'data' => null
            ]);
        }
    }

     /**
     * @OA\Get(
     *     path="/admin/delete/product/{id}",
     *     summary="delete product id",
     *     @OA\Response(
     *         response=200,
     *         description="OK",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="boolean", example=true),
     *             @OA\Property(property="data", type="string"),
     *         )
     *     )
     * )
     */ 
    public function destroy(string $id)
    {
        $get = product::find($id);
        $get->delete();

        return response()->json([
            'status' => true,
            'data' => null
        ]);
    }
}
