<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\product;
use App\Models\shopping_cart;
use App\Models\order;
use App\Models\category;

/**
 * @OA\Info(
 *     title="BACKEND API",
 *     version="1.0.0",
 *     description="BACKEND API",
 *     @OA\Contact(
 *         email="contact@example.com"
 *     ),
 * )
 */
class ApiController extends Controller
{

     /**
     * @OA\Get(
     *     path="api",
     *     summary="Get home",
     *     @OA\Response(
     *         response=200,
     *         description="OK",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="boolean", example=true),
     *             @OA\Property(property="message", type="string", example="Berhasil mengambil data"),
     *             @OA\Property(property="countproduct", type="integer", example=10000),
     *             @OA\Property(property="product", type="string")
     *         )
     *     )
     * )
     */

    public function index(Request $request, $nama = null)
    {
        if ($nama == null) {
            $product = Product::all();
            $productcount = $product->count();
        } else {
            $check_product = Product::where('nama', 'like', '%' . $nama . '%')->get();
            if($check_product) {
                $product = $check_product;
            } else {
                $check_category = Product::where('name', 'like', '%' . $nama . '%')->first();
                $product = Product::where('category_id', $check_category->id)->get();
            }
            $productcount = $product->count();
        }

        return response()->json([
            'status' => true,
            'message' => 'Berhasil mengambil data',
            'countproduct' => $productcount,
            'product' => $product
        ]);
    }

      /**
     * @OA\Get(
     *     path="api/cart/{id}",
     *     summary="Get shopping cart",
     *     @OA\Response(
     *         response=200,
     *         description="OK",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="boolean", example=true),
     *             @OA\Property(property="message", type="string", example="Berhasil mengambil data"),
     *             @OA\Property(property="totalprice", type="integer", example=10000),
     *             @OA\Property(property="cart", type="string")
     *         )
     *     )
     * )
     */

    public function shopping_cart($id){
        $get_cart = shopping_cart::where('user_id', $id)->get();

        $cart = [];

        foreach($get_cart as $datacart) {
            $data = [
                'id' => $datacart->id,
                'image' => $datacart->getproduct->image,
                'nama_product' => $datacart->getproduct->nama,
                'harga_product' => $datacart->getproduct->harga,
                'amount' => $datacart->amount,
                'harga' => $datacart->harga,
            ];

            array_push($cart, $data);
        }

        return response()->json([
            'status' => true,
            'message' => 'Berhasil mengambil data',
            'cart' => $cart,
            'totalprice' => $get_cart->sum('harga')
        ]);
    }

      /**
     * @OA\Get(
     *     path="api/check-out/{id}",
     *     summary="Get shopping cart",
     *     @OA\Response(
     *         response=200,
     *         description="OK",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="boolean", example=true),
     *             @OA\Property(property="message", type="string", example="Berhasil mengambil data"),
     *             @OA\Property(property="totalprice", type="integer", example=10000),
     *             @OA\Property(property="cart", type="string")
     *         )
     *     )
     * )
     */


    public function check_out($id){

        $get_cart = shopping_cart::where('user_id', $id)->get();

        $cart = [];

        foreach($get_cart as $datacart) {
            $data = [
                'id' => $datacart->id,
                'image' => $datacart->getproduct->image,
                'nama_product' => $datacart->getproduct->nama,
                'harga_product' => $datacart->getproduct->harga,
                'amount' => $datacart->amount,
                'harga' => $datacart->harga,
            ];

            array_push($cart, $data);
        }

        return response()->json([
            'status' => true,
            'message' => 'Pilih Product terlbeih dahulu',
            'cart' => $cart,
            'totalprice' => $get_cart->sum('harga')
        ]);
    }

    /**
 * @OA\Post(
 *     path="/api/check-out",
 *     summary="Checkout",
 *     @OA\RequestBody(
 *         required=true,
 *         description="Checkout details",
 *         @OA\JsonContent(
 *             required={"full_name", "address", "city", "state", "postcode", "phone", "note", "bukti_pembayaran"},
 *             @OA\Property(property="full_name", type="string", example="John Doe"),
 *             @OA\Property(property="address", type="string", example="123 Main St"),
 *             @OA\Property(property="city", type="string", example="City"),
 *             @OA\Property(property="state", type="string", example="State"),
 *             @OA\Property(property="postcode", type="string", example="12345"),
 *             @OA\Property(property="phone", type="string", example="123-456-7890"),
 *             @OA\Property(property="note", type="string", example="Some note"),
 *             @OA\Property(property="bukti_pembayaran", type="string", format="binary", example="base64 encoded image"),
 *         ),
 *     ),
 *     @OA\Response(
 *         response=200,
 *         description="Successful operation",
 *         @OA\JsonContent(
 *             @OA\Property(property="status", type="boolean", example=true),
 *             @OA\Property(property="message", type="string", example="Checkout successful"),
 *         ),
 *     ),
 * )
 */

    public function check_out_store(Request $request, $userid){

        $validatedData = $request->validate([
            'full_name' => 'required',
            'address' => 'required',
            'city' => 'required',
            'state' => 'required',
            'postcode' => 'required',
            'phone' => 'required',
            'note' => 'required',
            'bukti_pembayaran' => 'required',
        ]);

        $get_cart = shopping_cart::where('user_id', 1)->get();

        if(!$get_cart || empty($get_cart)) {
            return response()->json([
                'status' => false,
                'message' => 'Pilih Product terlbeih dahulu',
                'data' => null
            ]);
        }

        $total_harga =  $get_cart->sum('harga');
        
        $cart = [];
        foreach ($get_cart as $datacart) {
            $get_product = product::find($datacart->product_id);

            if($get_product->stock <  $datacart->amount) {
                return response()->json([
                    'status' => false,
                    'message' => 'Stock tidak cukup',
                    'data' => null
                ]);
            }

            $array = [
                'product_id' => $datacart->product_id,
                'product_name' => $get_product->nama,
                'amount' => $datacart->amount
            ];
            array_push($cart, $array);
        }

        if(empty($cart)) {
            return response()->json([
                'status' => false,
                'message' => 'Pilih Product terlbeih dahulu',
                'data' => null
            ]);
        }

        foreach ($get_cart as $datacart) {
            $get_product = product::find($datacart->product_id);
            $stock_now = $get_product->stock - $datacart->amount;
            $get_product->update(['stock' => $stock_now]);
        }

        $data = [
            'user_id' => $userid,
            'product' => json_encode($cart),
            'full_name' => $request->full_name,
            'address'  => $request->address,
            'city'  => $request->city,
            'state'  => $request->state,
            'postcode'  => $request->postcode,
            'phone'  => $request->phone,
            'note'  => $request->note,
            'total_harga'  => $total_harga,
            'bukti_pembayaran'  => $request->bukti_pembayaran,
            'status' => 'Waiting',
        ];

        $create = order::create($data);

        foreach ($get_cart as $cart_item) {
            $cart_item->delete();
        }

        if($create) {
            return response()->json([
                'status' => true,
                'message' => 'Pembelian berhasil silakan tunggu admin untuk tahap selanjutnya',
                'data' => null
            ]);
        } else {
            return response()->json([
                'status' => false,
                'message' => 'System Error',
                'data' => null
            ]);
        }
    }

    
      /**
     * @OA\Get(
     *     path="api/cart/remove/{id}",
     *     summary="Get shopping cart",
     *     @OA\Response(
     *         response=200,
     *         description="OK",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="boolean", example=true),
     *             @OA\Property(property="message", type="string", example="Berhasil mengambil data"),
     *         )
     *     )
     * )
     */

    public function remove_cart(Request $request, $id){

        $get_cart = shopping_cart::where('id', $id)->delete();
        if($get_cart) {
            return response()->json([
                'status' => true,
                'message' => 'Cart berhasil di remove',
                'data' => null
            ]);
        } else {
            return response()->json([
                'status' => false,
                'message' => 'System Error',
                'data' => null
            ]);
        }
    }

     /**
     * @OA\Get(
     *     path="api/add-cart/{productid}",
     *     summary="Get shopping cart",
     *     @OA\Response(
     *         response=200,
     *         description="OK",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="boolean", example=true),
     *             @OA\Property(property="message", type="string", example="Berhasil mengambil data"),
     *         )
     *     )
     * )
     */

    public function cart(Request $request, $productid, $userid){
        $get_product = product::find($productid);

        $check_cart = shopping_cart::where(['user_id' => 1, 'product_id' => $get_product->id])->first();

        if($check_cart) {
            $get_amount = $check_cart->amount + 1;

                if($get_product->stock < $get_amount) {
                    return response()->json([
                        'status' => false,
                        'message' => 'Stock tidak cukup',
                        'data' => null
                    ]);
                }

            $get_total_harga =  $get_amount * $get_product->harga;

            $add = shopping_cart::where(['user_id' => 1, 'product_id' => $get_product->id])->update([
                'amount' => $get_amount,
                'harga' => $get_total_harga,
            ]);
        } else {
            $get_amount = 1;

            if($get_product->stock < $get_amount) {
                return response()->json([
                    'status' => false,
                    'message' => 'Stock tidak cukup',
                    'data' => null
                ]);
            }

            $get_total_harga =  $get_amount * $get_product->harga;

            $add = shopping_cart::create([
                'user_id' => $userid,
                'product_id' =>  $get_product->id,
                'amount' => $get_amount,
                'harga' => $get_total_harga,
            ]);
        }

        if($add) {
            return response()->json([
                'status' => true,
                'message' => 'Berhasil di tambah ke keranjang',
                'data' => null
            ]);
        } else {
            return response()->json([
                'status' => false,
                'message' => 'System Error',
                'data' => null
            ]);
        }
    }
}
