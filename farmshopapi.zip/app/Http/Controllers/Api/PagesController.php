<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\order;
use App\Models\product;

class PagesController extends Controller
{

     /**
     * @OA\Get(
     *     path="/get-order/{userid}",
     *     summary="Get dashboard",
     *     @OA\Response(
     *         response=200,
     *         description="OK",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="boolean", example=true),
     *             @OA\Property(property="message", type="string", example="Berhasil mengambil data"),
     *             @OA\Property(property="data", type="string"),
     *         )
     *     )
     * )
     */
   public function get_orders($userid) {
        $get_order = order::where('user_id',$userid)->get();

        if($get_order) {
            return response()->json([
                'status' => true,
                'message' => 'Data berhasil di ambil',
                'data' => $get_order
            ]);
        } else {
            return response()->json([
                'status' => false,
                'message' => 'System Error',
                'data' => null
            ]);
        }
   }

    /**
     * @OA\Get(
     *     path="/get-product/{id}",
     *     summary="Get dashboard",
     *     @OA\Response(
     *         response=200,
     *         description="OK",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="boolean", example=true),
     *             @OA\Property(property="message", type="string", example="Berhasil mengambil data"),
     *             @OA\Property(property="data", type="string"),
     *         )
     *     )
     * )
     */
   public function get_product($id) {
    $get_product = order::where('id',$id)->first();

    if($get_product) {
        return response()->json([
            'status' => true,
            'message' => 'Data berhasil di ambil',
            'data' => $get_product->nama
        ]);
    } else {
        return response()->json([
            'status' => false,
            'message' => 'System Error',
            'data' => null
        ]);
    }
}
}
