<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Session;


class CheckRole
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next, $role): Response
    {

        if (!Session::has('level')) {
            return redirect()->route('login')->with('error', 'You must be logged in to access this page.');
        }

        if (Session::get('level') != $role) {
            return redirect()->route('dashboard')->with('error', 'tidak memiliki access.');
        }

        return $next($request);
    }
}
