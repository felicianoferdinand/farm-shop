<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use GuzzleHttp\Client;

class PagesController extends Controller
{
    public function dashboard(){
        $client = new Client();
        $response = $client->request('GET', 'http://127.0.0.1:8080/api/get-order/'.session('user_id'));
        $data = json_decode($response->getBody(), true);
        
        return view('pages.dashboard', [
            'order' => $data['data']
        ]);
    }
}
