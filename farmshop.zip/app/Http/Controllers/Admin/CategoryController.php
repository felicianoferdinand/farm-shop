<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use GuzzleHttp\Client;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $client = new Client();

        $response = $client->request('GET', 'http://127.0.0.1:8080/api/admin/category');

        $data = json_decode($response->getBody(), true);

        return view('pages.category.index', [
            'category' => $data['data']
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('pages.category.form');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
        ]);

        $client = new Client();
        $response = $client->request('POST', 'http://127.0.0.1:8080/api/admin/create/category', [
            'json' => [
                'name' => $request->name,
            ]
        ]);
        if ($response->getStatusCode() == 200) {
            $data = json_decode($response->getBody(), true);

            if($data['status'] == true) {
                return back()->with('success', 'Berhasil menambahkan data');
            } else {
                return back()->with('error', 'System Error');
            }
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $client = new Client();

        $response = $client->request('GET', 'http://127.0.0.1:8080/api/admin/category/'.$id);

        $data = json_decode($response->getBody(), true);

        return view('pages.category.form', [
            'edit' => $data['data']
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $request->validate([
            'name' => 'required',
        ]);

        $client = new Client();
        $response = $client->request('POST', 'http://127.0.0.1:8080/api/admin/update/category/'.$id, [
            'json' => [
                'name' => $request->name,
            ]
        ]);
        if ($response->getStatusCode() == 200) {
            $data = json_decode($response->getBody(), true);

            if($data['status'] == true) {
                return back()->with('success', 'Berhasil Update data');
            } else {
                return back()->with('error', 'System Error');
            }
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $client = new Client();

        $response = $client->request('GET', 'http://127.0.0.1:8080/api/admin/delete/category/'.$id);

        $data = json_decode($response->getBody(), true);

        if($data['status'] == true) {
            return back()->with('success', 'Berhasil Delete data');
        } else {
            return back()->with('error', 'System Error');
        }
    }
}
