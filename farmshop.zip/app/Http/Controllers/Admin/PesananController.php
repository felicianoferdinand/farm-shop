<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use GuzzleHttp\Client;

class PesananController extends Controller
{
    public function edit(string $id)
    {
        $client = new Client();

        $response = $client->request('GET', 'http://127.0.0.1:8080/api/admin/order/'.$id);

        $data = json_decode($response->getBody(), true);


        return view('pages.pesanan.form', [
            'edit' => $data['data']
        ]);
    }

    public function update(Request $request, string $id)
    {
        $client = new Client();

        $response = $client->request('POST', 'http://127.0.0.1:8080/api/admin/update/order/'.$id, [
            'json' => [
                'status' => $request->status,
            ]
        ]);
        if ($response->getStatusCode() == 200) {
            $data = json_decode($response->getBody(), true);

            if($data['status'] == true) {
                return back()->with('success', 'Berhasil Update data');
            } else {
                return back()->with('error', 'System Error');
            }
        }
    }
}
