<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use GuzzleHttp\Client;

class AuthController extends Controller
{
    public function login() {
        return view('auth.login', []);
    }

    public function register() {
        return view('auth.register', []);
    }

    public function veriflogin(Request $request) {
        $request->validate([
            'email' => 'required',
            'password' => 'required',
        ]);

        $client = new Client();
        $response = $client->request('POST', 'http://127.0.0.1:8080/api/login', [
            'json' => [
                'email' => $request->email,
                'password' => $request->password,
            ]
        ]);
        if ($response->getStatusCode() == 200) {
            $data = json_decode($response->getBody(), true);

            if($data['status'] == true) {
                session(['user_id' => $data['user_id']]);
                session(['level' => $data['level']]);
                return redirect()->route('dashboard')->with('success', $data['message']);
            } else {
                return redirect()->route('login')->with('error', $data['message']);
            }
        }

        return back()->with('error', 'Unable to process login.');
    }

    public function verifregister(Request $request) {
        $request->validate([
            'name' => 'required',
            'email' => 'required|unique:users',
            'password' => 'required',
        ]);

        $client = new Client();
        $response = $client->request('POST', 'http://127.0.0.1:8080/api/register', [
            'json' => [
                'name' => $request->name,
                'email' => $request->email,
                'password' => $request->password,
            ]
        ]);
        if ($response->getStatusCode() == 200) {
            $data = json_decode($response->getBody(), true);

            if($data['status'] == true) {
                return redirect()->route('login')->with('success', $data['message']);
            } else {
                return redirect()->route('login')->with('error', $data['message']);
            }
        }

        return back()->with('error', 'Unable to process login.');
    }

    public function logout(Request $request){
        $request->session()->flush();
        return redirect()->route('login')->with('success', 'You have been logged out successfully.');
    }
}
