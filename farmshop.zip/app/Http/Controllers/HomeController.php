<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\product;
use App\Models\shopping_cart;
use App\Models\order;
use GuzzleHttp\Client;

class HomeController extends Controller
{
    public function index(Request $request, $nama = null){

        $client = new Client();

        if ($nama == null) {
            $response = $client->request('GET', 'http://127.0.0.1:8080/api');
        } else {
            $response = $client->request('GET', "http://127.0.0.1:8080/api/".$nama);
        }

        $data = json_decode($response->getBody(), true);

        return view('pages.index', [
            'countproduct' => $data['countproduct'],
            'product' => $data['product']
        ]);
    }

    public function shopping_cart(){

        $client = new Client();
        $response = $client->request('GET', 'http://127.0.0.1:8080/api/cart/'.session('user_id'));
        $data = json_decode($response->getBody(), true);

        return view('pages.cart', [
            'cart' => $data['cart'],
            'totalprice' => $data['totalprice']
        ]);
    }

    public function check_out(){

        $client = new Client();
        $response = $client->request('GET', 'http://127.0.0.1:8080/api/check-out/'.session('user_id'));
        $data = json_decode($response->getBody(), true);

        return view('pages.checkout', [
            'cart' => $data['cart'],
            'totalprice' => $data['totalprice']
        ]);
    }

    public function check_out_store(Request $request){

        $request->validate([
            'full_name' => 'required',
            'address' => 'required',
            'city' => 'required',
            'state' => 'required',
            'postcode' => 'required',
            'phone' => 'required',
            'note' => 'required',
            'bukti_pembayaran' => 'required|image|mimes:jpeg,png,jpg,gif',
        ]);


        if ($request->hasFile('bukti_pembayaran')) {
            $fileNameimage = time() . '-image' . '.' . $request->bukti_pembayaran->extension();
            $imagePath = $request->bukti_pembayaran->move('uploads', $fileNameimage)->getPath();
            $image = $imagePath . '/' . $fileNameimage;
        }

        $client = new Client();
        $response = $client->request('POST', 'http://127.0.0.1:8080/api/check-out/'.session('user_id'), [
            'json' => [
                'full_name' => $request->full_name,
                'address' => $request->address,
                'city' => $request->city,
                'state' => $request->state,
                'postcode' => $request->postcode,
                'phone' => $request->phone,
                'note' => $request->note,
                'bukti_pembayaran' => $image,
            ]
        ]);
        if ($response->getStatusCode() == 200) {
            $data = json_decode($response->getBody(), true);

            if($data['status'] == true) {
                return redirect()->route('index')->with('success', $data['message']);
            } else {
                return redirect()->route('index')->with('error', $data['message']);
            }
        }
    }

    public function remove_cart(Request $request, $id){

        $client = new Client();
        $response = $client->request('GET', 'http://127.0.0.1:8080/api/cart/remove/'.$id);
        $data = json_decode($response->getBody(), true);

        if($data['status'] == true) {
            return back()->with('success', $data['message']);
        } else {
            return back()->with('error', $data['message']);
        }
    }

    public function cart(Request $request, $productid){
        $client = new Client();
        $response = $client->request('GET', 'http://127.0.0.1:8080/api/add-cart/'.$productid.'/'.session('user_id'));
        $data = json_decode($response->getBody(), true);

        if($data['status'] == true) {
            return back()->with('success', $data['message']);
        } else {
            return back()->with('error', $data['message']);
        }
    }
}
