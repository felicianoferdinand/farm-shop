@extends('component.template')
@section('content')
 <!-- Breadcrumb area start -->
 <div class="bd-breadcrumb__area include__bg hero__overlay Breadcrumb__height d-flex align-items-center" data-background="assets/img/hero/breadcrumb.jpg">
    <div class="container fluid">
       <div class="row">
          <div class="col-xl-12">
             <div class="bd-breadcrumb__menu">
                <nav aria-label="Breadcrumbs" class="breadcrumb-trail breadcrumbs">
                   <ul class="trail-items">
                      <li class="trail-item trail-end"><span>Register</span></li>
                   </ul>
                </nav>
             </div>
             <div class="bd-breadcrumb__title">
                <h2>Register</h2>
             </div>
          </div>
       </div>
    </div>
 </div>
 <!-- Breadcrumb area end-->

 <!-- Login area start  -->
 <div class="bd-login__area pt-120 pb-120">
    <div class="container small-container">
       <div class="row justify-content-center">
          <div class="col-lg-8">
             <div class="Login-form-wrapper">
                <div class="bd-postbox__contact">
                  @include('component.flash')
                   <form action="{{ route('register.post') }}" method="POST">
                     @csrf
                      <div class="row">
                        <div class="col-xxl-12">
                           <div class="bd-login__input">
                              <input type="text" name="name" placeholder="Enter Name">
                              <i class="fa-solid fa-user"></i>
                           </div>
                        </div>
                         <div class="col-xxl-12">
                            <div class="bd-login__input">
                               <input type="email" name="email" placeholder="Enter email">
                               <i class="fa-solid fa-user"></i>
                            </div>
                         </div>
                         <div class="col-xxl-12">
                            <div class="bd-login__input">
                               <input type="password" name="password" placeholder="Password">
                               <i class="fa-solid fa-key"></i>
                            </div>
                         </div>
                         <div class="signup-action">
                            <div class="signup-action-check">
                               <input class="e-check-input" type="checkbox" id="sing-up">
                               <label class="sign-check" for="sing-up"><span>Remember me</span></label>
                            </div>
                         </div>
                         <div class="bd-sigin__action-button mb-20">
                            <button type="submit" class="bd-login__btn w-100">Register</button>
                         </div>
                         <div class="bd-registered__wrapper">
                            <div class="not-register">
                              <span>already registered?</span><span><a href="{{ route('login')}}"> Sign in</a></span>
                            </div>
                         </div>
                      </div>
                   </form>
                </div>
             </div>
          </div>
       </div>
    </div>
 </div>
 <!-- Login area end  -->
 @endsection