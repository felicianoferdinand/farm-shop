<ul>
    <li>
       <a href="{{ route('index') }}">Home</a>
    </li>

   @if (session('level') == 'admin')
    <li>
       <a href="{{ route('category') }}">Category</a>
    </li>
   <li>
      <a href="{{ route('product') }}">Product</a>
   </li>
   <li>
      <a href="{{ route('dashboard') }}">Pesanan</a>
   </li>
   @elseif(session('level') == 'member')
   <li>
      <a href="{{ route('dashboard') }}">Pesanan</a>
   </li>
   @endif

   @if (session()->has('user_id'))
   <li>
      <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
         @csrf
     </form>
      <a href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
         Logout
     </a>
   </li>
 @endif
 </ul>