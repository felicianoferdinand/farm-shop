@extends('component.template')
@section('content')
  <!-- Breadcrumb area start -->
  <div class="bd-breadcrumb__area include__bg hero__overlay Breadcrumb__height d-flex align-items-center" data-background="assets/img/hero/breadcrumb.jpg">
    <div class="container fluid">
       <div class="row">
          <div class="col-xl-12">
             <div class="bd-breadcrumb__menu">
                <nav aria-label="Breadcrumbs" class="breadcrumb-trail breadcrumbs">
                   <ul class="trail-items">
                      <li class="trail-item trail-end"><span>Checkout</span></li>
                   </ul>
                </nav>
             </div>
             <div class="bd-breadcrumb__title">
                <h2>Checkout</h2>
             </div>
          </div>
       </div>
    </div>
 </div>
 <!-- Breadcrumb area end -->



 <!-- checkout-area start -->
 <section class="checkout-area pb-90" style="padding-top:30px;">
    <div class="container small-container">
       <form action="{{ route('shop.checkout.post') }}" method="POST" enctype="multipart/form-data">
        @csrf
          <div class="row">
            @include('component.flash')
             <div class="col-lg-6">
                <div class="checkbox-form">
                   <h3>Billing Details</h3>
                   <div class="row">
                      <div class="col-md-12">
                         <div class="checkout-form-list">
                            <label>Full Name <span class="required">*</span></label>
                            <input type="text" name="full_name" placeholder="" />
                            @error('full_name')
                            <span class="text-danger">{{ $message }}</span>
                        @enderror
                         </div>
                      </div>
                      <div class="col-md-12">
                         <div class="checkout-form-list">
                            <label>Address <span class="required">*</span></label>
                            <input type="text" name="address" placeholder="Street address" />
                            @error('address')
                            <span class="text-danger">{{ $message }}</span>
                        @enderror
                         </div>
                      </div>
                      <div class="col-md-12">
                         <div class="checkout-form-list">
                            <label>City <span class="required">*</span></label>
                            <input type="text" name="city" placeholder="City" />
                            @error('city')
                            <span class="text-danger">{{ $message }}</span>
                        @enderror
                         </div>
                      </div>
                      <div class="col-md-6">
                         <div class="checkout-form-list">
                            <label>State <span class="required">*</span></label>
                            <input type="text" name="state" placeholder="" />
                            @error('state')
                            <span class="text-danger">{{ $message }}</span>
                        @enderror
                         </div>
                      </div>
                      <div class="col-md-6">
                         <div class="checkout-form-list">
                            <label>Postcode / Zip <span class="required">*</span></label>
                            <input type="text" name="postcode" placeholder="Postcode / Zip" />
                            @error('postcode')
                            <span class="text-danger">{{ $message }}</span>
                        @enderror
                         </div>
                      </div>
                      <div class="col-md-12">
                         <div class="checkout-form-list">
                            <label>Phone <span class="required">*</span></label>
                            <input type="text" name="phone" placeholder="Phone number / Whatsapp" />
                            @error('phone')
                            <span class="text-danger">{{ $message }}</span>
                        @enderror
                         </div>
                      </div>
                      <div class="order-notes">
                        <div class="checkout-form-list">
                           <label>Order Notes</label>
                           <textarea id="checkout-mess" cols="30" rows="10" name="note"
                              placeholder="Masukan notes untuk pembelian anda."></textarea>
                              @error('note')
                              <span class="text-danger">{{ $message }}</span>
                          @enderror
                        </div>
                     </div>
                   </div>
                </div>
            </div>
                
             <div class="col-lg-6">
                <div class="your-order mb-30 ">
                   <h3>Your order</h3>
                   <div class="your-order-table table-responsive">
                      <table>
                         <thead>
                            <tr>
                               <th class="product-name">Product</th>
                               <th class="product-total">Total</th>
                            </tr>
                         </thead>
                         <tbody>
                            @foreach ($cart as $loopcart)
                            <tr class="cart_item">
                                <td class="product-name">
                                   {{ $loopcart['nama_product'] }}<strong class="product-quantity"> × {{$loopcart['amount']}}</strong>
                                </td>
                                <td class="product-total">
                                   <span class="amount">{{ "Rp " . number_format($loopcart['harga'], 0, ",", ".") }}</span>
                                </td>
                             </tr>
                            @endforeach
                         </tbody>
                         <tfoot>
                            <tr class="order-total">
                               <th>Order Total</th>
                               <td><strong><span class="amount">{{ "Rp " . number_format($totalprice, 0, ",", ".") }}</span></strong>
                               </td>
                            </tr>
                         </tfoot>
                      </table>
                   </div>

                   <div class="payment-method">
                      <div class="accordion" id="checkoutAccordion">
                         <div class="accordion-item">
                            <h2 class="accordion-header" id="checkoutOne">
                               <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                  data-bs-target="#bankOne" aria-expanded="true" aria-controls="bankOne">
                                  Direct Bank Transfer
                               </button>
                            </h2>
                            <div id="bankOne" class="accordion-collapse collapse show"
                               aria-labelledby="checkoutOne" data-bs-parent="#checkoutAccordion">
                               <div class="accordion-body">
                                  Silakan transfer rekening kami, berikut detailnya : <br/>
                                  No rekening : 213123123123<br/>
                                  Atas Nama : Mas wawan<br/>
                               </div>
                            </div>
                         </div>
                      </div>
                      <div class="checkout-form-list" style="padding-top:10px;">
                        <label>Bukti Pembayaran <span class="required">*</span></label>
                        <input type="file" class="form-check" name="bukti_pembayaran" placeholder="Bukti Pembayaran" />
                        @error('bukti_pembayaran')
                            <span class="text-danger">{{ $message }}</span>
                        @enderror
                     </div>
                      <div class="order-button-payment mt-20">
                         <button type="submit" class="bd-fill__btn-2">Place order</button>
                      </div>
                   </div>
                </div>
             </div>
          </div>
       </form>
    </div>
 </section>
 <!-- checkout-area end -->
 @endsection