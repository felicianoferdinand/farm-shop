@extends('component.template')
@section('content')

 <!-- Cart area start  -->
 <div class="cart-area pt-120 pb-120" style="background: #f9f5f5;">
    <div class="container small-container">
       <div class="row">
         @include('component.flash')
         <h4 class="text-center mb-4" style="font-size:25px;">PESANAN</h4>
          <div class="col-12">
             <form action="#">
                <div class="table-content table-responsive" style="background: white;padding:20px;">
                   <table class="table" id="table">
                      <thead>
                        <tr>
                            <th class="product-thumbnail">Product</th>
                            <th class="product-thumbnail">Quantity</th>
                            <th class="cart-product-name">Address</th>
                            <th class="cart-product-name">Phone</th>
                            <th class="product-price">Note</th>
                            <th class="product-quantity">Total Harga</th>
                            <th class="product-subtotal">Status</th>
                            @if (session('level') == 'admin')
                            <th class="product-subtotal">Action</th>
                            @endif
                         </tr>
                      </thead>
                      <tbody>
                        @foreach ($order as $orderItem)
                        @php
                           $products = json_decode($orderItem['product'], true);
                        @endphp
                        @foreach ($products as $product)
                        <tr>
                           <td class="product-name">{{ $product['product_name'] }}</td>
                           <td class="product-quantity">{{ $product['amount'] }}</td>
                           <td class="product-thumbnail">{{ $orderItem['address'] }}, {{ $orderItem['city'] }}, {{ $orderItem['state'] }}, {{ $orderItem['postcode'] }}</td>
                           <td class="product-price">{{ $orderItem['phone'] }}</td>
                           <td class="product-price">{{ $orderItem['note'] }}</td>
                           <td class="product-subtotal">{{ "Rp " . number_format($orderItem['total_harga'], 0, ",", ".") }}</td>
                           <td class="product-remove">{{ $orderItem['status'] }}</td>
                           @if (session('level') == 'admin')
                           <td class="product-remove"><a href="{{ route('pesanan.update', ['id' => $orderItem['id']])}}" type="button" class="btn btn-warning">Update</a></td>
                           @endif
                        </tr>
                        @endforeach
                        @endforeach
                      </tbody>
                   </table>
                </div>
             </form>
          </div>
       </div>

   </div>
    </div>
 </div>
 <!-- Cart area end  -->
 @endsection