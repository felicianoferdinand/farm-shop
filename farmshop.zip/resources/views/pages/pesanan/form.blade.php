@extends('component.template')
@section('content')
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
 <!-- Cart area start  -->
 <div class="cart-area pt-120 pb-120" style="background: #f9f5f5;">
    <div class="container small-container">
       <div class="row">
         @include('component.flash')
         <h4 class="text-center mb-4" style="font-size:25px;">Pesanan</h4>
          <div class="col-12">
            <form action="" method="POST" style="background: white;padding:20px;" enctype="multipart/form-data">
                @csrf
                 <div class="mb-4">
                    <label>Status<span class="required">*</span></label>
                    <select class="form-select mb-4" name="status" aria-label="status">
                        <option value="Pending" {{ isset($edit) && $edit['status'] == 'Pending' ? 'selected' : '' }}>Pending</option>
                        <option value="Waiting" {{ isset($edit) && $edit['status'] == 'Waiting' ? 'selected' : '' }}>Waiting</option>
                        <option value="Processing" {{ isset($edit) && $edit['status'] == 'Processing' ? 'selected' : '' }}>Processing</option>
                        <option value="Success" {{ isset($edit) && $edit['status'] == 'Success' ? 'selected' : '' }}>Success</option>
                      </select>
                 </div>
                 <button type="submit" class="btn btn-info mb-4">Submit</button>
             </form>
          </div>
       </div>

   </div>
    </div>
 </div>
 <!-- Cart area end  -->
 @endsection