@extends('component.template')
@section('content')

 <!-- Cart area start  -->
 <div class="cart-area pt-120 pb-120" style="background: #f9f5f5;">
    <div class="container small-container">
       <div class="row">
         @include('component.flash')
         <h4 class="text-center mb-4" style="font-size:25px;">Category</h4>
          <div class="col-12">
            <form action="" method="POST" style="background: white;padding:20px;">
                @csrf
                <div class="checkout-form-list">
                    <label>Name Category<span class="required">*</span></label>
                    <input type="text" name="name" placeholder="Masukan category name" value="{{ isset($edit) ? $edit['name'] : ''}}" />
                    @error('name')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                 </div>
                 <button type="submit" class="btn btn-info mb-4">Submit</button>
             </form>
          </div>
       </div>

   </div>
    </div>
 </div>
 <!-- Cart area end  -->
 @endsection