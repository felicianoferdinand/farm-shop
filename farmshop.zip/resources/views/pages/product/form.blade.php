@extends('component.template')
@section('content')
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
 <!-- Cart area start  -->
 <div class="cart-area pt-120 pb-120" style="background: #f9f5f5;">
    <div class="container small-container">
       <div class="row">
         @include('component.flash')
         <h4 class="text-center mb-4" style="font-size:25px;">Category</h4>
          <div class="col-12">
            <form action="" method="POST" style="background: white;padding:20px;" enctype="multipart/form-data">
                @csrf
                <div class="checkout-form-list">
                    <label>Image<span class="required">*</span></label>
                    <input type="file" name="image" />
                    @error('image')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                 </div>
                 <div class="checkout-form-list">
                    <label>Name Product<span class="required">*</span></label>
                    <input type="text" name="nama" placeholder="Masukan product name" value="{{ isset($edit) ? $edit['nama'] : ''}}" />
                    @error('nama')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                 </div>
                 <div class="checkout-form-list">
                    <label>Deskripsi<span class="required">*</span></label>
                    <input type="text" name="deskripsi" placeholder="Masukan product deskripsi" value="{{ isset($edit) ? $edit['deskripsi'] : ''}}" />
                    @error('deskripsi')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                 </div>
                 <div class="checkout-form-list">
                    <label>Harga<span class="required">*</span></label>
                    <input type="number" class="form-control" name="harga" placeholder="Masukan product harga" value="{{ isset($edit) ? $edit['harga'] : ''}}" />
                    @error('harga')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                 </div>
                 <div class="checkout-form-list">
                    <label>Stock<span class="required">*</span></label>
                    <input type="number" class="form-control" name="stock" placeholder="Masukan stock product" value="{{ isset($edit) ? $edit['stock'] : ''}}" />
                    @error('stock')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                 </div>
                 <div class="mb-4">
                    <label>Category<span class="required">*</span></label>
                    <select class="form-select mb-4" name="category" aria-label="category">
                        @foreach ($category as $datacategory)
                            <option value="{{ $datacategory['id'] }}" {{ isset($edit) && $edit['category_id'] == $datacategory['id'] ? 'selected' : '' }}>
                                {{ $datacategory['name'] }}
                            </option>
                        @endforeach
                      </select>
                 </div>
                 <button type="submit" class="btn btn-info mb-4">Submit</button>
             </form>
          </div>
       </div>

   </div>
    </div>
 </div>
 <!-- Cart area end  -->
 @endsection