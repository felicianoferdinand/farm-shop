@extends('component.template')
@section('content')

 <!-- Cart area start  -->
 <div class="cart-area pt-120 pb-120" style="background: #f9f5f5;">
    <div class="container small-container">
       <div class="row">
         @include('component.flash')
         <h4 class="text-center mb-4" style="font-size:25px;">Product</h4>
          <div class="col-12">
             <form action="#">
                <div class="table-content table-responsive" style="background: white;padding:20px;">
                    <a href="{{ route('product.create') }}" type="button" class="btn btn-success mb-4">Tambah data</a>
                   <table class="table" id="table">
                      <thead>
                        <tr>
                            <th class="product-thumbnail">Image</th>
                            <th class="product-thumbnail">Category ID</th>
                            <th class="product-thumbnail">Nama</th>
                            <th class="product-thumbnail">Deskripsi</th>
                            <th class="product-thumbnail">Harga</th>
                            <th class="product-thumbnail">Stock</th>
                            <th class="product-subtotal">Action</th>
                         </tr>
                      </thead>
                      <tbody>
                        @foreach ($product as $product)
                        <tr>
                           <td class="product-name"><img src="{{ asset($product['image']) }}" style="width:100px;"></td>
                           <td class="product-name">{{ $product['category_id'] }}</td>
                           <td class="product-name">{{ $product['nama'] }}</td>
                           <td class="product-name">{{ $product['deskripsi'] }}</td>
                           <td class="product-name">{{ $product['harga'] }}</td>
                           <td class="product-name">{{ $product['stock'] }}</td>
                           <td class="product-remove"><a href="{{ route('product.update', ['id' => $product['id']]) }}" type="button" class="btn btn-warning">Update</a>
                             <a href="{{ route('product.delete', ['id' => $product['id']]) }}" type="button" class="btn btn-danger">Delete</a></td>
                        </tr>
                        @endforeach
                      </tbody>
                   </table>
                </div>
             </form>
          </div>
       </div>

   </div>
    </div>
 </div>
 <!-- Cart area end  -->
 @endsection