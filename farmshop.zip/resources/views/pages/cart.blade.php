@extends('component.template')
@section('content')
 <!-- Breadcrumb area start -->
 <div class="bd-breadcrumb__area include__bg hero__overlay Breadcrumb__height d-flex align-items-center" data-background="assets/img/hero/breadcrumb.jpg">
    <div class="container fluid">
       <div class="row">
          <div class="col-xl-12">
             <div class="bd-breadcrumb__menu">
                <nav aria-label="Breadcrumbs" class="breadcrumb-trail breadcrumbs">
                   <ul class="trail-items">
                      <li class="trail-item trail-end"><span>Shopping cart</span></li>
                   </ul>
                </nav>
             </div>
             <div class="bd-breadcrumb__title">
                <h2>Shopping cart</h2>
             </div>
          </div>
       </div>
    </div>
 </div>
 <!-- Breadcrumb area start -->

 <!-- Cart area start  -->
 <div class="cart-area pt-120 pb-120">
    <div class="container small-container">
       <div class="row">
         @include('component.flash')
          <div class="col-12">
             <form action="#">
                <div class="table-content table-responsive">
                   <table class="table">
                      <thead>
                         <tr>
                            <th class="product-thumbnail">Image</th>
                            <th class="cart-product-name">Product</th>
                            <th class="product-price">Harga</th>
                            <th class="product-quantity">Amount</th>
                            <th class="product-subtotal">Total</th>
                            <th class="product-remove">Remove</th>
                         </tr>
                      </thead>
                      <tbody>
                        @foreach ($cart as $loopcart)
                        <tr>
                            <td class="product-thumbnail"><img
                               src="{{ asset($loopcart['image']) }}" alt="img"></td>
                            <td class="product-name">{{ $loopcart['nama_product'] }}</td>
                            <td class="product-price"><span class="amount">{{ "Rp " . number_format($loopcart['harga_product'], 0, ",", ".") }}</span></td>
                            <td class="product-quantity"><span class="amount">{{ $loopcart['amount'] }}</span></td>
                            <td class="product-subtotal"><span class="amount">{{ "Rp " . number_format($loopcart['harga'], 0, ",", ".") }}</span></td>
                            <td class="product-remove"><a href="{{ route('shop.cart.remove', ['id' => $loopcart['id']]) }}"><i class="fa fa-times"></i></a></td>
                         </tr>
                        @endforeach
                      </tbody>
                   </table>
                </div>
             </form>
          </div>
       </div>
      <div class="row">
         <div class="col-md-5 ml-auto">
            <div class="cart-page-total">
               <h2>Cart totals</h2>
               <ul class="mb-20">
                  <li>Total <span>{{ "Rp " . number_format($totalprice, 0, ",", ".") }}</span></li>
               </ul>
               <a class="bd-fill__btn-2" href="{{ route('shop.checkout')}}">Proceed to checkout</a>
            </div>
         </div>
      </div>
   </div>
    </div>
 </div>
 <!-- Cart area end  -->
 @endsection