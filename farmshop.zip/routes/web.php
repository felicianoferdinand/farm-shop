<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\PagesController;
use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\ProductController;
use App\Http\Controllers\Admin\PesananController;

Route::get('/', [HomeController::class, 'index'])->name('index');

Route::get('/login', [AuthController::class, 'login'])->name('login');
Route::post('/login', [AuthController::class, 'veriflogin'])->name('login.post');

Route::get('/register', [AuthController::class, 'register'])->name('register');
Route::post('/register', [AuthController::class, 'verifregister'])->name('register.post');


Route::middleware('auth')->group(function () {
    Route::get('/pesanan', [PagesController::class, 'dashboard'])->name('dashboard');

    Route::get('/add-cart/{productid}', [HomeController::class, 'cart'])->name('cart');
    Route::get('/cart', [HomeController::class, 'shopping_cart'])->name('shop.cart');
    Route::get('/cart/remove/{id}', [HomeController::class, 'remove_cart'])->name('shop.cart.remove');
    Route::get('/check-out', [HomeController::class, 'check_out'])->name('shop.checkout');
    Route::post('/check-out', [HomeController::class, 'check_out_store'])->name('shop.checkout.post');

    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
});

Route::middleware(['auth', 'role:admin'])->group(function () {
    Route::get('/admin/category', [CategoryController::class, 'index'])->name('category');
    Route::get('/admin/create/category', [CategoryController::class, 'create'])->name('category.create');
    Route::post('/admin/create/category', [CategoryController::class, 'store'])->name('category.create.post');
    Route::get('/admin/update/category/{id}', [CategoryController::class, 'edit'])->name('category.update');
    Route::post('/admin/update/category/{id}', [CategoryController::class, 'update'])->name('category.update.post');
    Route::get('/admin/delete/category/{id}', [CategoryController::class, 'destroy'])->name('category.delete');

    Route::get('/admin/product', [ProductController::class, 'index'])->name('product');
    Route::get('/admin/create/product', [ProductController::class, 'create'])->name('product.create');
    Route::post('/admin/create/product', [ProductController::class, 'store'])->name('product.create.post');
    Route::get('/admin/update/product/{id}', [ProductController::class, 'edit'])->name('product.update');
    Route::post('/admin/update/product/{id}', [ProductController::class, 'update'])->name('product.update.post');
    Route::get('/admin/delete/product/{id}', [ProductController::class, 'destroy'])->name('product.delete');

    Route::get('/admin/update/pesanan/{id}', [PesananController::class, 'edit'])->name('pesanan.update');
    Route::post('/admin/update/pesanan/{id}', [PesananController::class, 'update'])->name('pesanan.update.post');
});

Route::get('/{nama?}', [HomeController::class, 'index'])->name('index');
