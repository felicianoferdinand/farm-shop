
<?php $__env->startSection('content'); ?>

 <!-- Cart area start  -->
 <div class="cart-area pt-120 pb-120" style="background: #f9f5f5;">
    <div class="container small-container">
       <div class="row">
         <?php echo $__env->make('component.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <h4 class="text-center mb-4" style="font-size:25px;">Category</h4>
          <div class="col-12">
            <form action="" method="POST" style="background: white;padding:20px;">
                <?php echo csrf_field(); ?>
                <div class="checkout-form-list">
                    <label>Name Category<span class="required">*</span></label>
                    <input type="text" name="name" placeholder="Masukan category name" value="<?php echo e(isset($edit) ? $edit['name'] : ''); ?>" />
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                 </div>
                 <button type="submit" class="btn btn-info mb-4">Submit</button>
             </form>
          </div>
       </div>

   </div>
    </div>
 </div>
 <!-- Cart area end  -->
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('component.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Xampp\htdocs\farmshop\resources\views/pages/category/form.blade.php ENDPATH**/ ?>