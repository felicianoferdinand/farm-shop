
<?php $__env->startSection('content'); ?>
   <!-- Breadcrumb area start -->
   <div class="bd-breadcrumb__area include__bg hero__overlay Breadcrumb__height d-flex align-items-center" data-background="<?php echo e(asset('assets/img/hero/breadcrumb.jpg')); ?>">
    <div class="container fluid">
       <div class="row">
          <div class="col-xl-12">
             <div class="bd-breadcrumb__menu">
                <nav aria-label="Breadcrumbs" class="breadcrumb-trail breadcrumbs">
                   <ul class="trail-items">
                      <li class="trail-item trail-end"><span>products</span></li>
                   </ul>
                </nav>
             </div>
             <div class="bd-breadcrumb__title">
                <h2>OUR PRODUCT</h2>
             </div>
          </div>
       </div>
    </div>
 </div>
 <!-- Breadcrumb area end -->

 <!-- Product area start -->
 <section class="bd-product__area pt-115 pb-90">
    <div class="container">
       <div class="row">
         <form id="searchForm" class="mb-4" action="<?php echo e(route('index')); ?>" method="GET">
            <div class="col-md-12">
                <div class="checkout-form-list">
                    <input id="searchInput" type="text" name="search" placeholder="Masukan nama category atau nama product" />
                </div>
            </div>
            <div class="order-button-payment">
                <button type="submit" class="bd-fill__btn-2" style="height: 30px;font-size:15px;">Cari product</button>
            </div>
        </form>
          <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6">
             <div class="bd-product__result mb-30">
                <h4><?php echo e($countproduct); ?> Items yang tersedia</h4>
             </div>
          </div>
       </div>
       <div class="row">
          <div class="col-xxl-12">
             <div class="product__filter-tab">
                <div class="tab-content" id="nav-tabContent">
                   <div class="tab-pane fade active show" id="nav-grid" role="tabpanel" aria-labelledby="nav-grid-tab">
                      <div class="row">

                        <?php echo $__env->make('component.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loopproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xl-3 col-lg-4 col-md-6">
                           <div class="bd-product__item text-center mb-30">
                              <div class="bd-product__img">
                                 <img src="<?php echo e(asset($loopproduct['image'])); ?>" alt="product-img">
                              </div>
                              <div class="bd-product__content">
                                 <h4><?php echo e($loopproduct['nama']); ?></h4>
                                 <span class="bd-product__new-price"><?php echo e("Rp " . number_format($loopproduct['harga'], 0, ",", ".")); ?></span>
                              </div>
                              <div class="bd-product__action">
                                 <a type="button" class="cart-btn" href="<?php echo e(route('cart', ['productid' => $loopproduct['id']])); ?>"><i class="fal fa-cart-arrow-down"></i></a>
                               </div>
                           </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                   </div>
                  
                </div>
             </div>
          </div>
       </div>
      
    </div>
 </section>
 
 <!-- Product area end -->
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('component.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Xampp\htdocs\farmshop\resources\views/pages/index.blade.php ENDPATH**/ ?>