
<?php $__env->startSection('content'); ?>
  <!-- Breadcrumb area start -->
  <div class="bd-breadcrumb__area include__bg hero__overlay Breadcrumb__height d-flex align-items-center" data-background="assets/img/hero/breadcrumb.jpg">
    <div class="container fluid">
       <div class="row">
          <div class="col-xl-12">
             <div class="bd-breadcrumb__menu">
                <nav aria-label="Breadcrumbs" class="breadcrumb-trail breadcrumbs">
                   <ul class="trail-items">
                      <li class="trail-item trail-end"><span>Checkout</span></li>
                   </ul>
                </nav>
             </div>
             <div class="bd-breadcrumb__title">
                <h2>Checkout</h2>
             </div>
          </div>
       </div>
    </div>
 </div>
 <!-- Breadcrumb area end -->



 <!-- checkout-area start -->
 <section class="checkout-area pb-90" style="padding-top:30px;">
    <div class="container small-container">
       <form action="<?php echo e(route('shop.checkout.post')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
          <div class="row">
            <?php echo $__env->make('component.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             <div class="col-lg-6">
                <div class="checkbox-form">
                   <h3>Billing Details</h3>
                   <div class="row">
                      <div class="col-md-12">
                         <div class="checkout-form-list">
                            <label>Full Name <span class="required">*</span></label>
                            <input type="text" name="full_name" placeholder="" />
                            <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                         </div>
                      </div>
                      <div class="col-md-12">
                         <div class="checkout-form-list">
                            <label>Address <span class="required">*</span></label>
                            <input type="text" name="address" placeholder="Street address" />
                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                         </div>
                      </div>
                      <div class="col-md-12">
                         <div class="checkout-form-list">
                            <label>City <span class="required">*</span></label>
                            <input type="text" name="city" placeholder="City" />
                            <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                         </div>
                      </div>
                      <div class="col-md-6">
                         <div class="checkout-form-list">
                            <label>State <span class="required">*</span></label>
                            <input type="text" name="state" placeholder="" />
                            <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                         </div>
                      </div>
                      <div class="col-md-6">
                         <div class="checkout-form-list">
                            <label>Postcode / Zip <span class="required">*</span></label>
                            <input type="text" name="postcode" placeholder="Postcode / Zip" />
                            <?php $__errorArgs = ['postcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                         </div>
                      </div>
                      <div class="col-md-12">
                         <div class="checkout-form-list">
                            <label>Phone <span class="required">*</span></label>
                            <input type="text" name="phone" placeholder="Phone number / Whatsapp" />
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                         </div>
                      </div>
                      <div class="order-notes">
                        <div class="checkout-form-list">
                           <label>Order Notes</label>
                           <textarea id="checkout-mess" cols="30" rows="10" name="note"
                              placeholder="Masukan notes untuk pembelian anda."></textarea>
                              <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                     </div>
                   </div>
                </div>
            </div>
                
             <div class="col-lg-6">
                <div class="your-order mb-30 ">
                   <h3>Your order</h3>
                   <div class="your-order-table table-responsive">
                      <table>
                         <thead>
                            <tr>
                               <th class="product-name">Product</th>
                               <th class="product-total">Total</th>
                            </tr>
                         </thead>
                         <tbody>
                            <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loopcart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="cart_item">
                                <td class="product-name">
                                   <?php echo e($loopcart['nama_product']); ?><strong class="product-quantity"> × <?php echo e($loopcart['amount']); ?></strong>
                                </td>
                                <td class="product-total">
                                   <span class="amount"><?php echo e("Rp " . number_format($loopcart['harga'], 0, ",", ".")); ?></span>
                                </td>
                             </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </tbody>
                         <tfoot>
                            <tr class="order-total">
                               <th>Order Total</th>
                               <td><strong><span class="amount"><?php echo e("Rp " . number_format($totalprice, 0, ",", ".")); ?></span></strong>
                               </td>
                            </tr>
                         </tfoot>
                      </table>
                   </div>

                   <div class="payment-method">
                      <div class="accordion" id="checkoutAccordion">
                         <div class="accordion-item">
                            <h2 class="accordion-header" id="checkoutOne">
                               <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                  data-bs-target="#bankOne" aria-expanded="true" aria-controls="bankOne">
                                  Direct Bank Transfer
                               </button>
                            </h2>
                            <div id="bankOne" class="accordion-collapse collapse show"
                               aria-labelledby="checkoutOne" data-bs-parent="#checkoutAccordion">
                               <div class="accordion-body">
                                  Silakan transfer rekening kami, berikut detailnya : <br/>
                                  No rekening : 213123123123<br/>
                                  Atas Nama : Mas wawan<br/>
                               </div>
                            </div>
                         </div>
                      </div>
                      <div class="checkout-form-list" style="padding-top:10px;">
                        <label>Bukti Pembayaran <span class="required">*</span></label>
                        <input type="file" class="form-check" name="bukti_pembayaran" placeholder="Bukti Pembayaran" />
                        <?php $__errorArgs = ['bukti_pembayaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>
                      <div class="order-button-payment mt-20">
                         <button type="submit" class="bd-fill__btn-2">Place order</button>
                      </div>
                   </div>
                </div>
             </div>
          </div>
       </form>
    </div>
 </section>
 <!-- checkout-area end -->
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('component.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Xampp\htdocs\farmshop\resources\views/pages/checkout.blade.php ENDPATH**/ ?>