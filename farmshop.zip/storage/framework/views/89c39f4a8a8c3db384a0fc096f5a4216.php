<!doctype html>
<html class="no-js" lang="zxx">
   
<!-- Mirrored from codeskdhaka.com/html/dairypress-prev/dairypress/shop.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 09 Jun 2024 15:11:12 GMT -->
<head>
      <meta charset="utf-8">
      <meta http-equiv="x-ua-compatible" content="ie=edge">
      <title>Dairy Farm HTML5 Template</title>
      <meta name="description" content="">
      <meta name="viewport" content="width=device-width, initial-scale=1">

      <!-- Place favicon.ico in the root directory -->
      <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/img/favicon.png')); ?>">

      <!-- CSS here -->
      <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('assets/css/meanmenu.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl-carousel.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('assets/css/swiper-bundle.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('assets/css/backtotop.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('assets/css/magnific-popup.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('assets/css/nice-select.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('assets/css/font-awesome-pro.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('assets/css/spacing.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>">
      <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.css">
   </head>
   <body>
   <!-- Added to cart message  -->
   <!-- Header area start -->
   <header>
      <div id="header-sticky" class="bd-header__area">
         <div class="container-fluid p-0">
            <div class="row g-0 align-items-center">
               <div class="col-xl-2 col-lg-2 col-md-4 col-4 p-0">
                  <div class="bd-header__logo">
                     <a href="<?php echo e(url('')); ?>">
                        <img src="<?php echo e(asset('assets/img/logo/logo.png')); ?>" alt="logo">
                     </a>
                  </div>
                  
               </div>
               <div class="col-xl-8 col-lg-9 col-md-4 d-none d-md-block">
                  <div class="bd-header__menu-wrapper d-flex justify-content-center">
                     <div class="main-menu d-none d-none d-lg-block">
                        <nav id="mobile-menu">
                           <?php if(Auth::check()): ?>
                           <?php if(Auth::user()->level == 'Admin'): ?>
                               <?php echo $__env->make('component.sidebaradmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                           <?php else: ?>
                               <?php echo $__env->make('component.sidebaruser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                           <?php endif; ?>
                       <?php else: ?>
                           <?php echo $__env->make('component.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                       <?php endif; ?>
                        </nav>
                     </div>
                  </div>
               </div>
               <div class="col-xl-2 col-lg-1 col-md-4 col-8">
                  <div class="bd-header__right d-flex align-items-center justify-content-end">
                     <div class="bd-header__hamburger">
                        <div class="bd-header__hamburger-icon">
                           <a href="<?php echo e(route('shop.cart')); ?>" class="shoping__toggle" style="padding-right:20px;">
                              <img src="<?php echo e(asset('assets/img/icon/cart-icon.png')); ?>" alt="cart-icon">
                           </a>
                        </div>
                     </div>
                     <div class="bd-header__hamburger">
                        <div class="bd-header__hamburger-icon">
                           <?php if(session()->has('user_id')): ?>
                              <a href="<?php echo e(route('dashboard')); ?>" class="shoping__toggle" style="padding-right:20px;">
                                 <i class="fa fa-user fa-lg" aria-hidden="true"></i>
                              </a>
                           <?php else: ?>
                           <a href="<?php echo e(route('login')); ?>" class="shoping__toggle" style="padding-right:20px;">
                              <i class="fa fa-user fa-lg" aria-hidden="true"></i>
                           </a>
                           <?php endif; ?>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </header>
   <!-- Header area end -->

   <!-- Body main wrapper start -->
   <main>

  <?php echo $__env->yieldContent('content'); ?>


   </main>
   <!-- Body main wrapper start -->

   <!-- Footer area start -->
   <footer>
      <section class="bd-footer__area green-bg foo p-relative pt-95">
         <div class="bd-footer__bg w-img">
            <img src="<?php echo e(asset('assets/img/bg/footer-bg.png')); ?>" alt="footer-bg">
         </div>
         <div class="container">
            <div class="row">
               <div class="col-xl-3 col-lg-4 col-md-6">
                  <div class="bd-footer__widget footer-col-1 mb-60">
                     <div class="bd-footer__title">
                        <h4>about us</h4>
                     </div>
                     <div class="bd-footer__paragraph">
                        <p>A farm is a plot of land that is used to
                           grow crops and raise livestock, as in
                           our farm, we raise sheep and sell their
                           wool. The word farm is also used as a
                           verb to mean to work land.</p>
                     </div>
                     <div class="bd-footer__social">
                        <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
                        <a href="#"><i class="fa-brands fa-twitter"></i></a>
                        <a href="#"><i class="fa-brands fa-behance-square"></i></a>
                        <a href="#"><i class="fa-brands fa-youtube"></i></a>
                     </div>
                  </div>
               </div>
               
               <div class="col-xl-3 col-lg-4 col-md-6">
                  <div class="bd-footer__widget footer-col-3 mb-60">
                     <div class="bd-footer__title">
                        <h4>Business hours</h4>
                     </div>
                     <div class="bd-footer__contact">
                        <div class="bd-footer__contact-item">
                           <span>Mon - Fri</span>
                           <p class="mb-20">10:00 am to 06:00 pm</p>
                        </div>
                        <div class="bd-footer__contact-item">
                           <span>Saturday (1st & 4th)</span>
                           <p class="mb-25">08:00 am to 04:00 pm</p>
                        </div>
                        <div class="bd-footer__support">
                           <div class="bd-footer__support-inner">
                              <div class="bd-footer__support-icon">
                                 <img src="<?php echo e(asset('assets/img/icon/footer-text.png')); ?>" alt="footer-text">
                              </div>
                              <div class="bd-footer__support-title">
                                 <span>Emergency Service</span>
                                 <a href="tel:00011122233">000 111 222 33</a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               

            </div>
         </div>
         <div class="bd-copyright__area">
            <div class="container">
               <div class="row">
                  <div class="col-12">
                     <div class="bd-copyright__main">
                        <div class="bd-copyright__border">
                           <div class="bd-copyright__text">
                              <p>Copyright by <span> @ILHPEDIA</span> - 2024</p>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
   </footer>
   <!-- Footer area end -->

   <!-- Back to top start -->
   <div class="progress-wrap">
      <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
         <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
      </svg>
   </div>
   <!-- Back to top end -->
   
   <!-- JS here -->
   <script src="<?php echo e(asset('assets/js/vendor/jquery.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/js/vendor/waypoints.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/js/bootstrap-bundle.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/js/meanmenu.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/js/swiper-bundle.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/js/owl-carousel.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/js/magnific-popup.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/js/parallax.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/js/backtotop.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/js/nice-select.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/js/counterup.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/js/wow.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/js/isotope-pkgd.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/js/imagesloaded-pkgd.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/js/ajax-form.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
   <!-- Include jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<!-- Include DataTables JS -->
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.js"></script>

<script>
   $(document).ready( function () {
      $('#table').DataTable();
   });
</script>


<script>
   document.getElementById('searchForm').addEventListener('submit', function(event) {
       var searchValue = document.getElementById('searchInput').value.trim();
       if (!searchValue) {
           return;
       }
       event.preventDefault();
       this.action = '/' + searchValue;
       var url = new URL(this.action, window.location.origin);
       url.searchParams.delete('search');
       window.location.href = url;
   });
</script>
   </body>

<!-- Mirrored from codeskdhaka.com/html/dairypress-prev/dairypress/shop.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 09 Jun 2024 15:11:45 GMT -->
</html>
<?php /**PATH G:\Xampp\htdocs\farmshop\resources\views/component/template.blade.php ENDPATH**/ ?>