
<?php $__env->startSection('content'); ?>

 <!-- Cart area start  -->
 <div class="cart-area pt-120 pb-120" style="background: #f9f5f5;">
    <div class="container small-container">
       <div class="row">
         <?php echo $__env->make('component.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <h4 class="text-center mb-4" style="font-size:25px;">Product</h4>
          <div class="col-12">
             <form action="#">
                <div class="table-content table-responsive" style="background: white;padding:20px;">
                    <a href="<?php echo e(route('product.create')); ?>" type="button" class="btn btn-success mb-4">Tambah data</a>
                   <table class="table" id="table">
                      <thead>
                        <tr>
                            <th class="product-thumbnail">Image</th>
                            <th class="product-thumbnail">Category ID</th>
                            <th class="product-thumbnail">Nama</th>
                            <th class="product-thumbnail">Deskripsi</th>
                            <th class="product-thumbnail">Harga</th>
                            <th class="product-thumbnail">Stock</th>
                            <th class="product-subtotal">Action</th>
                         </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                           <td class="product-name"><img src="<?php echo e(asset($product['image'])); ?>" style="width:100px;"></td>
                           <td class="product-name"><?php echo e($product['category_id']); ?></td>
                           <td class="product-name"><?php echo e($product['nama']); ?></td>
                           <td class="product-name"><?php echo e($product['deskripsi']); ?></td>
                           <td class="product-name"><?php echo e($product['harga']); ?></td>
                           <td class="product-name"><?php echo e($product['stock']); ?></td>
                           <td class="product-remove"><a href="<?php echo e(route('product.update', ['id' => $product['id']])); ?>" type="button" class="btn btn-warning">Update</a>
                             <a href="<?php echo e(route('product.delete', ['id' => $product['id']])); ?>" type="button" class="btn btn-danger">Delete</a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                   </table>
                </div>
             </form>
          </div>
       </div>

   </div>
    </div>
 </div>
 <!-- Cart area end  -->
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('component.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Xampp\htdocs\farmshop\resources\views/pages/product/index.blade.php ENDPATH**/ ?>