
<?php $__env->startSection('content'); ?>

 <!-- Cart area start  -->
 <div class="cart-area pt-120 pb-120" style="background: #f9f5f5;">
    <div class="container small-container">
       <div class="row">
         <?php echo $__env->make('component.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <h4 class="text-center mb-4" style="font-size:25px;">Category</h4>
          <div class="col-12">
             <form action="#">
                <div class="table-content table-responsive" style="background: white;padding:20px;">
                    <a href="<?php echo e(route('category.create')); ?>" type="button" class="btn btn-success mb-4">Tambah data</a>
                   <table class="table" id="table">
                      <thead>
                        <tr>
                            <th class="product-thumbnail">Name</th>
                            <th class="product-subtotal">Action</th>
                         </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                           <td class="product-name"><?php echo e($category['name']); ?></td>
                           <td class="product-remove"><a href="<?php echo e(route('category.update', ['id' => $category['id']])); ?>" type="button" class="btn btn-warning">Update</a>
                             <a href="<?php echo e(route('category.delete', ['id' => $category['id']])); ?>" type="button" class="btn btn-danger">Delete</a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                   </table>
                </div>
             </form>
          </div>
       </div>

   </div>
    </div>
 </div>
 <!-- Cart area end  -->
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('component.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Xampp\htdocs\farmshop\resources\views/pages/category/index.blade.php ENDPATH**/ ?>