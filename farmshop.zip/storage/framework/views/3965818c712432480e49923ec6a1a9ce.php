<ul>
    <li>
       <a href="<?php echo e(route('index')); ?>">Home</a>
    </li>

   <?php if(session('level') == 'admin'): ?>
    <li>
       <a href="<?php echo e(route('category')); ?>">Category</a>
    </li>
   <li>
      <a href="<?php echo e(route('product')); ?>">Product</a>
   </li>
   <li>
      <a href="<?php echo e(route('dashboard')); ?>">Pesanan</a>
   </li>
   <?php elseif(session('level') == 'member'): ?>
   <li>
      <a href="<?php echo e(route('dashboard')); ?>">Pesanan</a>
   </li>
   <?php endif; ?>

   <?php if(session()->has('user_id')): ?>
   <li>
      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
         <?php echo csrf_field(); ?>
     </form>
      <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
         Logout
     </a>
   </li>
 <?php endif; ?>
 </ul><?php /**PATH G:\Xampp\htdocs\farmshop\resources\views/component/sidebar.blade.php ENDPATH**/ ?>