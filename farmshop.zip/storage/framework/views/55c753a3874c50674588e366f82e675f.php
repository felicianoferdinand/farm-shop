
<?php $__env->startSection('content'); ?>
 <!-- Breadcrumb area start -->
 <div class="bd-breadcrumb__area include__bg hero__overlay Breadcrumb__height d-flex align-items-center" data-background="assets/img/hero/breadcrumb.jpg">
    <div class="container fluid">
       <div class="row">
          <div class="col-xl-12">
             <div class="bd-breadcrumb__menu">
                <nav aria-label="Breadcrumbs" class="breadcrumb-trail breadcrumbs">
                   <ul class="trail-items">
                      <li class="trail-item trail-end"><span>Shopping cart</span></li>
                   </ul>
                </nav>
             </div>
             <div class="bd-breadcrumb__title">
                <h2>Shopping cart</h2>
             </div>
          </div>
       </div>
    </div>
 </div>
 <!-- Breadcrumb area start -->

 <!-- Cart area start  -->
 <div class="cart-area pt-120 pb-120">
    <div class="container small-container">
       <div class="row">
         <?php echo $__env->make('component.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <div class="col-12">
             <form action="#">
                <div class="table-content table-responsive">
                   <table class="table">
                      <thead>
                         <tr>
                            <th class="product-thumbnail">Image</th>
                            <th class="cart-product-name">Product</th>
                            <th class="product-price">Harga</th>
                            <th class="product-quantity">Amount</th>
                            <th class="product-subtotal">Total</th>
                            <th class="product-remove">Remove</th>
                         </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loopcart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="product-thumbnail"><img
                               src="<?php echo e(asset($loopcart['image'])); ?>" alt="img"></td>
                            <td class="product-name"><?php echo e($loopcart['nama_product']); ?></td>
                            <td class="product-price"><span class="amount"><?php echo e("Rp " . number_format($loopcart['harga_product'], 0, ",", ".")); ?></span></td>
                            <td class="product-quantity"><span class="amount"><?php echo e($loopcart['amount']); ?></span></td>
                            <td class="product-subtotal"><span class="amount"><?php echo e("Rp " . number_format($loopcart['harga'], 0, ",", ".")); ?></span></td>
                            <td class="product-remove"><a href="<?php echo e(route('shop.cart.remove', ['id' => $loopcart['id']])); ?>"><i class="fa fa-times"></i></a></td>
                         </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                   </table>
                </div>
             </form>
          </div>
       </div>
      <div class="row">
         <div class="col-md-5 ml-auto">
            <div class="cart-page-total">
               <h2>Cart totals</h2>
               <ul class="mb-20">
                  <li>Total <span><?php echo e("Rp " . number_format($totalprice, 0, ",", ".")); ?></span></li>
               </ul>
               <a class="bd-fill__btn-2" href="<?php echo e(route('shop.checkout')); ?>">Proceed to checkout</a>
            </div>
         </div>
      </div>
   </div>
    </div>
 </div>
 <!-- Cart area end  -->
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('component.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Xampp\htdocs\farmshop\resources\views/pages/cart.blade.php ENDPATH**/ ?>