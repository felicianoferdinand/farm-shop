
<?php $__env->startSection('content'); ?>

 <!-- Cart area start  -->
 <div class="cart-area pt-120 pb-120" style="background: #f9f5f5;">
    <div class="container small-container">
       <div class="row">
         <?php echo $__env->make('component.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <h4 class="text-center mb-4" style="font-size:25px;">PESANAN</h4>
          <div class="col-12">
             <form action="#">
                <div class="table-content table-responsive" style="background: white;padding:20px;">
                   <table class="table" id="table">
                      <thead>
                        <tr>
                            <th class="product-thumbnail">Product</th>
                            <th class="product-thumbnail">Quantity</th>
                            <th class="cart-product-name">Address</th>
                            <th class="cart-product-name">Phone</th>
                            <th class="product-price">Note</th>
                            <th class="product-quantity">Total Harga</th>
                            <th class="product-subtotal">Status</th>
                            <?php if(session('level') == 'admin'): ?>
                            <th class="product-subtotal">Action</th>
                            <?php endif; ?>
                         </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                           $products = json_decode($orderItem['product'], true);
                        ?>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                           <td class="product-name"><?php echo e($product['product_name']); ?></td>
                           <td class="product-quantity"><?php echo e($product['amount']); ?></td>
                           <td class="product-thumbnail"><?php echo e($orderItem['address']); ?>, <?php echo e($orderItem['city']); ?>, <?php echo e($orderItem['state']); ?>, <?php echo e($orderItem['postcode']); ?></td>
                           <td class="product-price"><?php echo e($orderItem['phone']); ?></td>
                           <td class="product-price"><?php echo e($orderItem['note']); ?></td>
                           <td class="product-subtotal"><?php echo e("Rp " . number_format($orderItem['total_harga'], 0, ",", ".")); ?></td>
                           <td class="product-remove"><?php echo e($orderItem['status']); ?></td>
                           <?php if(session('level') == 'admin'): ?>
                           <td class="product-remove"><a href="<?php echo e(route('pesanan.update', ['id' => $orderItem['id']])); ?>" type="button" class="btn btn-warning">Update</a></td>
                           <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                   </table>
                </div>
             </form>
          </div>
       </div>

   </div>
    </div>
 </div>
 <!-- Cart area end  -->
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('component.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Xampp\htdocs\farmshop\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>