
<?php $__env->startSection('content'); ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
 <!-- Cart area start  -->
 <div class="cart-area pt-120 pb-120" style="background: #f9f5f5;">
    <div class="container small-container">
       <div class="row">
         <?php echo $__env->make('component.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <h4 class="text-center mb-4" style="font-size:25px;">Category</h4>
          <div class="col-12">
            <form action="" method="POST" style="background: white;padding:20px;" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="checkout-form-list">
                    <label>Image<span class="required">*</span></label>
                    <input type="file" name="image" />
                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                 </div>
                 <div class="checkout-form-list">
                    <label>Name Product<span class="required">*</span></label>
                    <input type="text" name="nama" placeholder="Masukan product name" value="<?php echo e(isset($edit) ? $edit['nama'] : ''); ?>" />
                    <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                 </div>
                 <div class="checkout-form-list">
                    <label>Deskripsi<span class="required">*</span></label>
                    <input type="text" name="deskripsi" placeholder="Masukan product deskripsi" value="<?php echo e(isset($edit) ? $edit['deskripsi'] : ''); ?>" />
                    <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                 </div>
                 <div class="checkout-form-list">
                    <label>Harga<span class="required">*</span></label>
                    <input type="number" class="form-control" name="harga" placeholder="Masukan product harga" value="<?php echo e(isset($edit) ? $edit['harga'] : ''); ?>" />
                    <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                 </div>
                 <div class="checkout-form-list">
                    <label>Stock<span class="required">*</span></label>
                    <input type="number" class="form-control" name="stock" placeholder="Masukan stock product" value="<?php echo e(isset($edit) ? $edit['stock'] : ''); ?>" />
                    <?php $__errorArgs = ['stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                 </div>
                 <div class="mb-4">
                    <label>Category<span class="required">*</span></label>
                    <select class="form-select mb-4" name="category" aria-label="category">
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datacategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($datacategory['id']); ?>" <?php echo e(isset($edit) && $edit['category_id'] == $datacategory['id'] ? 'selected' : ''); ?>>
                                <?php echo e($datacategory['name']); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                 </div>
                 <button type="submit" class="btn btn-info mb-4">Submit</button>
             </form>
          </div>
       </div>

   </div>
    </div>
 </div>
 <!-- Cart area end  -->
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('component.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Xampp\htdocs\farmshop\resources\views/pages/product/form.blade.php ENDPATH**/ ?>